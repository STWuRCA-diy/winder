#!/bin/bash
# Uruchomienie sterownika nawijarki na RPi / Linux
cd "$(dirname "$0")"
python3 winder4.py
